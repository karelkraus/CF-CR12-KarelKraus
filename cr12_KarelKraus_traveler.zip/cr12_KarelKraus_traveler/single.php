<?php get_header(); ?>

	<div class="container">
		<?php if(have_posts()) :  ?>
			<div class="col-12 mt-5 pt-2 pb-3 mb-5 pageText">
				<?php while(have_posts()) : the_post(); ?>
					<h2 class="text-center"><?php the_title(); ?></h2>
				<?php the_post_thumbnail( 'small','style=object-fit:cover; max-width:100%;height:50vh;'); ?>
				<p class="text-center"><?php the_time('F j, Y g:i a'); ?></p>
				<hr class="breakLine">
				<?php the_content(); ?>
				<hr class="breakLine">
			</div>
			
			<div class="col-12 pt-2 commentPlace">
				<?php comments_template(); ?>
			</div>
		<?php endwhile; ?>
		
		<?php else : ?>
			<?php __('No posts found'); ?>
		<?php endif; ?>

	</div>



<?php get_footer(); ?>