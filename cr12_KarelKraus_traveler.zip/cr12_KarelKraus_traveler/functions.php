<?php  

function something() {

//register jQuery
wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.5.0.min.js', array(),'1.0', true);

wp_enqueue_style('bootstrap-css', get_template_directory_uri().'/css/bootstrap.css');
wp_enqueue_style('main style sheet', get_template_directory_uri().'/style.css', array(), rand(111,9999), 'all');
wp_enqueue_script('bootsrap-js', get_template_directory_uri().'/js/bootstrap.js', array(), '1.0', true);

}

add_action('wp_enqueue_scripts', 'something');

/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
	register_nav_menus( array(
    'primary' => __( 'Top Menu', 'THEMENAME' ),
) );
}
add_action( 'after_setup_theme', 'register_navwalker' );

add_theme_support('post-thumbnails');

/* Adding widgets */

function register_widgets() {
	register_sidebar(array(
		'name' => 'sidebar',
		'id' => 'sidebar',
		'before_widget' => '<div class="sidebar">',
		'after_widget' => '</div>'

	));
}

add_action('widgets_init','register_widgets');


/* Adding custom headline, text and image */

function my_heading($wp_customize) {
	$wp_customize->add_section('my-top-heading', array( 
		'title' => 'Top heading'
	));

	$wp_customize->add_setting('top-heading-display', array(
		'default' => 'No'
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 
		'top-heading-display-control', array(
			'label' => 'Display this section?',
			'section' => 'my-top-heading',
			'settings' => 'top-heading-display',
			'type' => 'select',
			'choices' => array('No' => 'No', 'Yes' => 'Yes')
	)));

	$wp_customize->add_setting('top-heading-callout', array(
		'default' => 'Here comes your heading!'
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 
		'top-heading-callout-control', array(
			'label' => 'Headline',
			'section' => 'my-top-heading',
			'settings' => 'top-heading-callout'
	)));

	$wp_customize->add_setting('top-text-callout', array(
		'default' => 'Here comes your text!'
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 
		'top-text-callout-control', array(
			'label' => 'Text',
			'section' => 'my-top-heading',
			'settings' => 'top-text-callout',
			'type' => 'textarea'
	)));

	$wp_customize->add_setting('main-image-callout');

	$wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 
		'main-image-callout-control', array(
			'label' => 'Image',
			'section' => 'my-top-heading',
			'settings' => 'main-image-callout',
			'width' => 1280,
			'height' => 420
	)));
}

add_action('customize_register', 'my_heading')


?>