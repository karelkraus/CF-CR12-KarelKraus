<?php get_header(); ?>

	<div class="container-fluid pb-3" style="min-height: 100vh; background-color: rgba(248,249,250, 0.8) !important;">

		<?php if(have_posts()) :  ?>
			<?php while(have_posts()) : the_post(); ?>
				<h1 class="text-center p-2"><?php the_title(); ?></h1>
				<?php the_post_thumbnail( 'small','style=object-fit:cover; max-width:100%;height:20vh;'); ?>
			    <p class="text-justify"><?php the_content(); ?></p>
			<?php endwhile; ?>
		<?php else : ?>
			<?php __('No posts found'); ?>
		<?php endif; ?>
		
	</div>

<?php get_footer(); ?>