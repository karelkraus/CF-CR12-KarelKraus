<?php get_header(); ?>

	<div class="container-fluid d-flex indexMobile" style="min-height: 100vh; padding-right: 0;">
		<?php if(have_posts()) :  ?>
			<div class="col-12 col-lg-9">
				<?php while(have_posts()) : the_post(); ?>
					<div class="card mt-5 mb-5 blogCard">
						<?php the_post_thumbnail( 'small','style=object-fit:cover; max-width:100%;height:20vh;'); ?>
				  		<div class="card-body bg-light blogCardText">
					    	<a class="cardHeading" href="<?php the_permalink(); ?>"><h5 class="card-title"><?php the_title(); ?></h5></a>
					    	<?php the_excerpt(); ?>
					   		<h6 class="card-text"><small class="text-muted"><?php the_time('F j, Y g:i a'); ?></small></h6>
				  		</div>
					</div>
		<?php endwhile; ?>
		
		<?php else : ?>
			<?php __('No posts found'); ?>
		<?php endif; ?>
		
			</div>

		<!-- widget menu -->

		<div class="col-12 col-lg-3 pt-2 rightMenu">
			 <?php 
			if (is_active_sidebar('sidebar')): 
				dynamic_sidebar('sidebar');
			endif;
			 ?>
		</div>
	
	</div>

<?php get_footer(); ?>