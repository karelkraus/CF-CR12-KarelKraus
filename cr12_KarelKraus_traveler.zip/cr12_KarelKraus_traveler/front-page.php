<?php get_header(); ?>

	<div class="banner">
		<h2 id="text">Discover...</h2>
		<div class="clouds">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud1.png" style="--i:1;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud2.png" style="--i:2;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud3.png" style="--i:3;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud4.png" style="--i:4;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud5.png" style="--i:5;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud1.png" style="--i:10;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud2.png" style="--i:9;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud3.png" style="--i:8;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud4.png" style="--i:7;">
			<img src="<?php echo get_template_directory_uri(); ?>/img/cloud5.png" style="--i:6;">
		</div>
	</div>

	<!-- For customized heading, text and picture -->

<?php if(get_theme_mod('top-heading-display') == 'Yes') { ?>

	<div class="container-fluid frontPage">
		<div class="row">
			<div class="col-12">
				<h1 class="text-dark text-center pt-3 pb-2"><?php echo get_theme_mod('top-heading-callout') ?></h1>
				<?php echo wpautop(get_theme_mod('top-text-callout')) ?>
			</div>
			<img src="<?php echo wp_get_attachment_url(get_theme_mod('main-image-callout')) ?>" class="col-12">

		</div>
	</div>

<?php } ?>


	<div class="col-12 bg-light d-flex justify-content-center align-items-center" style="height: 7vh;">
		<h6><?php  bloginfo('pagename') ?> &#169; 2020</h6>
	</div>

	<script type="text/javascript">
		let text =  document.getElementById('text');
		window.addEventListener('scroll', function(){
			let value = window.scrollY;
			text.style.marginBottom = value * 2 + 'px';
		})
	</script>

	<?php wp_footer(); ?>
</body>
</html>