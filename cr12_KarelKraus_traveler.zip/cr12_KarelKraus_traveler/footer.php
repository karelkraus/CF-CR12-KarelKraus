	<div class="col-12 bg-light d-flex justify-content-center align-items-center" style="height: 7vh;">
		<h6><?php  bloginfo('pagename') ?> &#169; 2020</h6>
	</div>

	<?php wp_footer(); ?>
</body>
</html>